</main>
  </div>
</div>
<script src="<?= base_url('assets/dist/js/bootstrap.bundle.min.js')?>"></script>

    <script src="<?= base_url('assets/js/chart.js')?>" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/njoSsxfbrkCTnJrzXt+ENP5MOVBxD+l6sEG4zoLp" crossorigin="anonymous">

    </script>
    <script src="<?= base_url('assets/js/dashboard.js')?>"></script>
</body>
</html>